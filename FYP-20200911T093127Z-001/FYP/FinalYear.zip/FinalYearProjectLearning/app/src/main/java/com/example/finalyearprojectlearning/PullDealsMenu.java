package com.example.finalyearprojectlearning;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PullDealsMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pull_deals_menu);
    }
}
